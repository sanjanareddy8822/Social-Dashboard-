const themeToggle = document.getElementById("themeToggle");
const storedTheme = localStorage.getItem("dashboard-theme");

if (storedTheme === "dark") {
  document.body.classList.add("dark");
  themeToggle.setAttribute("aria-pressed", "true");
  themeToggle.querySelector(".toggle-icon").textContent = "☾";
}

themeToggle.addEventListener("click", () => {
  const dark = document.body.classList.toggle("dark");
  localStorage.setItem("dashboard-theme", dark ? "dark" : "light");
  themeToggle.setAttribute("aria-pressed", String(dark));
  themeToggle.querySelector(".toggle-icon").textContent = dark ? "☾" : "☼";
});

// Small interaction: animate metric bars when they enter the viewport.
const bars = document.querySelectorAll(".bar, .progress i");
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = "1";
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.25 });

bars.forEach(bar => {
  bar.style.opacity = "0.25";
  observer.observe(bar);
});
