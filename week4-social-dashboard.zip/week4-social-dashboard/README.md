# SocialPulse — Week 4 Assignment

A responsive social media dashboard built with HTML, CSS and vanilla JavaScript.

This project is inspired by the Week 4 course:
**Build a Simple Website with HTML, CSS, JavaScript — Course for Beginners**.

Course video:
https://youtu.be/krfUjg0S2uI

## Features

- Responsive social media dashboard
- Four social-platform overview cards
- Daily performance metric cards
- Weekly reach bar chart
- Recent activity panel
- Light/dark theme toggle
- Theme preference saved with `localStorage`
- CSS Grid and Flexbox
- Responsive mobile/tablet/desktop layouts
- Accessible theme control
- No framework required

## Files

```text
week4-social-dashboard/
├── index.html
├── style.css
├── script.js
├── README.md
└── assets/
```

## Run

Open `index.html` directly in a browser or use VS Code Live Server.

## GitHub

```bash
git init
git add .
git commit -m "Complete Week 4 social media dashboard"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/week4-social-dashboard.git
git push -u origin main
```

## Note

This is an original implementation of the course concepts, with original dashboard branding/content rather than copying the instructor's source code.
